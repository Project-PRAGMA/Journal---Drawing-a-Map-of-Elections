#!/usr/bin/env python
# This plot was generated using a previous version of mapel library.

import other.voting.mapel as mapel


if __name__ == "__main__":

    experiment_id = "preflib_plus"
    mapel.print_highest_plurality(experiment_id)
    mapel.print_highest_borda(experiment_id)
    mapel.print_highest_copeland(experiment_id)
    mapel.print_highest_dodgson(experiment_id)
