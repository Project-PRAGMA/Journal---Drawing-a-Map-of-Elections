import mapel.elections as mapel

from utils_compute import compute_features

if __name__ == "__main__":
    experiment_id = 'main_100x100'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                          distance_id=distance_id,
                                                          embedding_id=embedding_id,
                                                          )
    committee_size = 10

    feature_ids = {
        'highest_cc_score': {'committee_size': committee_size},
        'highest_hb_score': {'committee_size': committee_size},
    }

    compute_features(experiment, feature_ids, committee_size)