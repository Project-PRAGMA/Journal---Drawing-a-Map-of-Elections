import mapel.elections as mapel

import numpy as np


def print_feature_table_by_models(experiment):
    list_of_models = [
        'Impartial Culture',
        'SP by Conitzer',
        'SP by Walsh',
        'SPOC',
        'Single-Crossing',
        '1D Uniform',
        '2D Uniform',
        '3D Uniform',
        '5D Uniform',
        '10D Uniform',
        '20D Uniform',
        '2D Sphere',
        '3D Sphere',
        '5D Sphere',
        'GS Balanced',
        'GS Caterpillar',
        'Urn',
        'Norm-Mallows',
    ]

    features = {}
    features['cc'] = experiment.import_feature(feature_id='highest_cc_score', column_id='time')
    features['hb'] = experiment.import_feature(feature_id='highest_hb_score', column_id='time')
    features['dodgson'] = experiment.import_feature(feature_id='lowest_dodgson_score',
                                                    column_id='time')

    results = {}
    for feature_id in features:

        results[feature_id] = {}
        for model in list_of_models:
            results[feature_id][model] = {'mean': None, 'std': None}
            total_value = []
            for instance_id in features[feature_id]:
                if model.lower() in instance_id.lower():
                    value = features[feature_id][instance_id]
                    if value is not None:
                        total_value.append(value)

            total_value = np.array(total_value)
            results[feature_id][model]['mean'] = round(np.mean(total_value), 1)
            results[feature_id][model]['std'] = round(np.std(total_value), 1)

    for model in list_of_models:
        print(f'{model} & '
              f'{results["cc"][model]["mean"]}s & '
              f'{results["cc"][model]["std"]} & '
              f'{results["hb"][model]["mean"]}s & '
              f'{results["hb"][model]["std"]} & '
              f'{results["dodgson"][model]["mean"]}s & '
              f'{results["dodgson"][model]["std"]} \\\\')


if __name__ == "__main__":

    experiment_id = 'main_100x100'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                      distance_id=distance_id,
                                      fast_import=True
                                      )

    print_feature_table_by_models(experiment)
