from datetime import time

from matplotlib.transforms import Bbox

import mapel.elections as mapel
import itertools
from scipy.stats import stats
import matplotlib.pyplot as plt
import numpy as np
import math


def compute_features(experiment, feature_ids, committee_size=None):
    # feature_ids = {

    # 'highest_pav_score': {'committee_size': committee_size},
    # 'clustering': {}
    # 'greedy_approx_hb_score': {'committee_size': committee_size},
    # 'removal_approx_hb_score': {'committee_size': committee_size},
    # 'greedy_approx_pav_score': {'committee_size': committee_size},
    # 'removal_approx_pav_score': {'committee_size': committee_size},

    # 'rand_approx_pav_score': {'committee_size': committee_size},
    # 'num_of_diff_votes': {},
    # 'voterlikeness_sqrt': {},
    # 'voterlikeness_harmonic': {},
    # 'borda_diversity': {},
    # }

    for feature_id in feature_ids:
        experiment.compute_feature(feature_id=feature_id,
                                   printing=True,
                                   # committee_size=committee_size
                                   )


def normalize_features(experiment, feature_ids):
    # DISSAT ##

    for feature_id in feature_ids:

        if feature_id in ['greedy_approx_cc_score', 'removal_approx_cc_score',
                          'banzhaf_cc_score', 'ranging_cc_score']:
            feature_denom = 'highest_cc_score'

        elif feature_id in ['greedy_approx_hb_score', 'removal_approx_hb_score']:
            feature_denom = 'highest_hb_score'

        experiment.normalize_feature_by_feature(nom=feature_id,
                                                denom=feature_denom,
                                                saveas=f'{feature_id}_normalized_dissat',
                                                column_id='dissat')
