import itertools
import math

import numpy as np

import mapel.elections as mapel


def get_euclidean_distance(coordinates, election_id_1, election_id_2):
    x1 = coordinates[election_id_1][0]
    y1 = coordinates[election_id_1][1]
    x2 = coordinates[election_id_2][0]
    y2 = coordinates[election_id_2][1]
    return ((x1-x2)**2 + (y1-y2)**2)**0.5


if __name__ == "__main__":

    num_iterations = 2
    distance_id = 'emd-positionwise'

    algorithms = [
        'fr',
        'mds',
        'kk'
    ]

    total_pcc = {algorithm: [] for algorithm in algorithms}
    total_distortion = {algorithm: [] for algorithm in algorithms}
    total_mono = {algorithm: [] for algorithm in algorithms}

    for i in range(num_iterations):

        print(i)
        for algorithm in algorithms:
            print(algorithm)
            experiment_id = f'dataset_100x100/d{i}'

            experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                                     distance_id=distance_id,
                                                                     embedding_id=algorithm)
            X = []
            Y = []
            for election_id_1, election_id_2 in itertools.combinations(experiment.elections, 2):
                original_distance = experiment.distances[election_id_1][election_id_2]
                euclidean_distance = get_euclidean_distance(experiment.coordinates, election_id_1,
                                                            election_id_2)
                X.append(original_distance)
                Y.append(euclidean_distance)

            original_distances = X
            embedded_distances = Y

            mono = experiment.import_feature(feature_id=f'monotonicity_{algorithm}').values()
            mono = [float(x) for x in mono if x is not None and x != math.inf]
            avg_mono = sum(mono) / len(mono)
            total_mono[algorithm].append(avg_mono)



    print("Monotonicity")
    for embedding_id in total_distortion:
        np_array = np.array(total_distortion[embedding_id])
        print(embedding_id, round(np.mean(np_array), 4), round(np.std(np_array), 4))
    print()
