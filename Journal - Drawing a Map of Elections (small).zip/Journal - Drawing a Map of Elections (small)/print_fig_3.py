import mapel.elections as mapel
import itertools
from scipy.stats import stats
import matplotlib.pyplot as plt
import numpy as np


def print_paths(embedding_id):
    experiment.print_map_2d(
        legend=False,
        shading=True,
        saveas=f'{experiment_id}_{embedding_id}',
        textual=['ID', 'UN', 'AN', 'ST'],
        textual_size=16,
        show=True,
        ms=40,
    )


if __name__ == "__main__":

    experiment_id = 'paths'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(
                                          experiment_id=f'{experiment_id}',
                                          distance_id=distance_id,
                                          embedding_id=embedding_id,
                                          fast_import=True
    )

    print_paths(embedding_id)
