
import mapel.elections as mapel


if __name__ == "__main__":

    num_iterations = 2
    distance_id = 'emd-positionwise'

    algorithms = [
        'fr',
        'mds',
        'kk'
    ]


    for i in range(num_iterations):

        print(i)
        for algorithm in algorithms:
            print(algorithm)
            experiment_id = f'dataset_100x100/d{i}'

            experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                                     distance_id=distance_id,
                                                                     embedding_id=algorithm)

            experiment.compute_feature(feature_id=f'monotonicity')
