
import mapel.elections as mapel


if __name__ == "__main__":
    experiment_id = 'paths'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(
        experiment_id=f'{experiment_id}',
        distance_id=distance_id,
        embedding_id=embedding_id)

    experiment.prepare_elections()
    experiment.compute_distances(distance_id=distance_id)

    experiment.embed_2d(embedding_id=embedding_id,
                        init_pos={'UN': [-1600, 0],
                                  'ID': [1600, 0],
                                  'AN': [-520, 1320],
                                  'ST': [450, -1350],
                                  },
                        fixed=True)
