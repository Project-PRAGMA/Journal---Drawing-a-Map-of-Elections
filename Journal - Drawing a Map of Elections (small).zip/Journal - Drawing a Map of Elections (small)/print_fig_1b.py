#!/usr/bin/env python
# This plot was generated using a previous version of mapel library.

import other.voting.mapel as mapel


if __name__ == "__main__":

    experiment_id = "preflib_plus"

    mapel.print_main_preflib_map_2d(experiment_id)
