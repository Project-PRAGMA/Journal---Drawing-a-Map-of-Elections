import mapel.elections as mapel


if __name__ == "__main__":

    experiment_id = '100x100'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_offline_ordinal_experiment(
                                          experiment_id=f'{experiment_id}',
                                          distance_id=distance_id,
    )

    experiment.prepare_elections()
    experiment.compute_distances(distance_id=distance_id)

    embbeding_ids = ['fr', 'kk', 'mds']
    for embedding_id in embbeding_ids:
        experiment.embed_2d(embedding_id)
