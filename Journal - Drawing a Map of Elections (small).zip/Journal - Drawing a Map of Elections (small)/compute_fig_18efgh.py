import mapel.elections as mapel


if __name__ == "__main__":
    experiment_id = f'main_10x100'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                          distance_id=distance_id,
                                                          embedding_id=embedding_id)

    for feature_id in ['highest_plurality_score', 'highest_borda_score',
                       'highest_copeland_score', 'lowest_dodgson_score']:
        experiment.compute_feature(feature_id=feature_id)