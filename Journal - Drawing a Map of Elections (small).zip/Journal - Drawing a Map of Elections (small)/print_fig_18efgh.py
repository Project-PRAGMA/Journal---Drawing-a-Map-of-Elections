import sys
import mapel.elections as mapel


def print_10x100_highest_plurality_score(experiment):
    cmap = mapel.custom_div_cmap(
        colors=["black", "blue", "purple", "red", "orange", "yellowgreen", "green"])
    feature_id = 'highest_plurality_score'
    # experiment.compute_feature(feature_id=feature_id)
    experiment.print_map_2d_colored_by_feature(feature_id=feature_id,
                                               strech=[10, 100],
                                               rounding=0,
                                               saveas=feature_id,
                                               cmap=cmap,
                                               figsize=(6.8, 6.8))

def print_10x100_highest_borda_score(experiment):


    cmap = mapel.custom_div_cmap(colors=["black", "blue", "purple", "red", "orange", "yellowgreen", "green"])
    feature_id = 'highest_borda_score'
    experiment.compute_feature(feature_id=feature_id)
    experiment.print_map_2d_colored_by_feature(feature_id=feature_id,
                                               strech=[450, 900],
                                               rounding=0,
                                               saveas=feature_id,
                                               cmap=cmap,
                                                 figsize=(6.8, 6.8))


def print_10x100_highest_copeland_score(experiment):

    def marker_func(x):
        if x == 1.:
            return 'x'
        return 'o'

    cmap = mapel.custom_div_cmap(
        colors = ["black", "blue", "purple", "red", "orange", "yellowgreen", "green"],
        num_colors=9)

    feature_id = 'highest_copeland_score'
    experiment.compute_feature(feature_id=feature_id)
    experiment.print_map_2d_colored_by_feature(feature_id=feature_id,
                                               marker_func=marker_func,
                                               xticklabels=['5', '6', '7', '8', '9'],
                                               ticks_pos=[0.056, 0.278, 0.5, 0.722, 0.944],
                                               saveas=feature_id,
                                               cmap=cmap,
                                                  figsize=(6.8, 6.8))

def print_10x100_lowest_dodgson_score():


    def marker_func(x):
        if x == 0.:
            return 'x'
        return 'o'

    cmap = mapel.custom_div_cmap(
        colors=["black", "blue", "purple", "red", "orange", "yellowgreen", "green"],
        num_colors=16)

    feature_id = 'lowest_dodgson_score'
    # experiment.compute_feature(feature_id=feature_id)
    experiment.print_map_2d_colored_by_feature(feature_id=feature_id,
                                               marker_func=marker_func,
                                               rounding=0,
                                               xticklabels=['0', '3', '6', '9', '12', '15'],
                                               ticks_pos=[0.033,  0.221,  0.408, 0.596,  0.783,  0.971],
                                               saveas=feature_id,
                                               cmap=cmap,
                                                  figsize=(6.8, 6.8))


if __name__ == "__main__":
    experiment_id = f'main_10x100'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                          distance_id=distance_id,
                                                          embedding_id=embedding_id)



