#!/usr/bin/env python

from . import elections as el
from . import winners as win
from . import metrics as metr
from . import objects as obj
import time
import os
import csv
import random as rand
from scipy import stats
from shutil import copyfile
import numpy as np
from collections import Counter

# from skopt import gp_minimize
import matplotlib.pyplot as plt


def merge_segments(experiment_id, num_segments):

    file_name = "election/" + experiment_id + "/results/distances/" + str(experiment_id) + "_info.txt"
    file_input = open(file_name, 'r')

    file_name = "election/" + experiment_id + "/results/distances/" + str(experiment_id) + ".txt"
    file_output = open(file_name, 'w')

    file_output.write(file_input.readline())  # first line
    file_output.write(file_input.readline())  # second line
    file_output.write(file_input.readline())  # third line
    file_input.close()

    for segment in range(num_segments):

        file_name = "election/" + experiment_id + "/results/distances/" + str(experiment_id) + "_" + str(segment) + ".txt"
        file_input = open(file_name, 'r')
        num_distances = int(file_input.readline())

        for i in range(num_distances):
            file_output.write(file_input.readline())

        file_input.close()

LIST_OF_PREFLIB_ELECTIONS = {'sushi', 'irish', 'glasgow', 'skate', 'formula',
                             'tshirt', 'cities_survey', 'aspen', 'ers',
                             'marble', 'cycling_tdf', 'cycling_gdi', 'ice_races'}


def prepare_elections(experiment_id, folder=None, starting_from=0, ending_at=10000):

    model = obj.Model(experiment_id)
    id_ = 0

    for i in range(model.num_families):

        election_model = model.families[i].name
        param_1 = model.families[i].param_1
        param_2 = model.families[i].param_2
        copy_param_1 = param_1

        if id_ >= starting_from and id_ < ending_at:

            # PREFLIB
            if election_model in LIST_OF_PREFLIB_ELECTIONS:

                selection_method = 'borda'

                # list of IDs larger than 10
                if election_model == 'irish':
                    folder = 'irish_s1'
                    ids = [1, 3]
                elif election_model == 'glasgow':
                    folder = 'glasgow_s1'
                    ids = [2, 3, 4, 5, 6, 7, 8, 9, 11, 13, 16, 19, 21]
                elif election_model == 'formula':
                    folder = 'formula_s1'
                    # 17 races or more
                    ids = [17, 35, 37, 40, 41, 42, 44, 45, 46, 47, 48]
                elif election_model == 'skate':
                    folder = 'skate_ic'
                    # 9 judges
                    ids = [1, 2, 3, 4, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 47, 48]
                elif election_model == 'sushi':
                    folder = 'sushi_ff'
                    ids = [1]
                elif election_model == 'tshirt':
                    folder = 'tshirt_ff'
                    ids = [1]
                elif election_model == 'cities_survey':
                    folder = 'cities_survey_s1'
                    ids = [1, 2]
                elif election_model == 'aspen':
                    folder = 'aspen_s1'
                    ids = [1]
                elif election_model == 'marble':
                    folder = 'marble_ff'
                    ids = [1, 2, 3, 4, 5]
                elif election_model == 'cycling_tdf':
                    folder = 'cycling_tdf_s1'
                    #ids = [e for e in range(1, 69+1)]
                    selection_method = 'random'
                    ids = [14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26]
                elif election_model == 'cycling_gdi':
                    folder = 'cycling_gdi_s1'
                    ids = [i for i in range(2, 23+1)]
                elif election_model == 'ers':
                    folder = 'ers_s1'
                    # 500 voters or more
                    ids = [3, 9, 23, 31, 32, 33, 36, 38, 40, 68, 77, 79, 80]
                elif election_model == 'ice_races':
                    folder = 'ice_races_s1'
                    # 80 voters or more
                    ids = [4, 5, 8, 9, 15, 20, 23, 24, 31, 34, 35, 37, 43, 44, 49]
                else:
                    ids = []

                print(model.families[i].size)
                rand_ids = rand.choices(ids, k=model.families[i].size)
                for ri in rand_ids:
                    elections_id = "core_" + str(id_)
                    tmp_elections_type = election_model + '_' + str(ri)
                    print(tmp_elections_type)
                    el.generate_elections_preflib(experiment_id, election_model=tmp_elections_type, elections_id=elections_id,
                                                  num_voters=model.num_voters, num_candidates=model.num_candidates,
                                                  special=param_1, folder=folder, selection_method=selection_method)
                    id_ += 1

            # STATISTICAL CULTURE
            else:

                base = []
                if election_model == 'crate':
                    my_size = 9
                    # with_edge
                    for p in range(my_size):
                        for q in range(my_size):
                            for r in range(my_size):
                                a = p / (my_size - 1)
                                b = q / (my_size - 1)
                                c = r / (my_size - 1)
                                d = 1 - a - b - c
                                tmp = [a, b, c, d]
                                if d >= 0 and sum(tmp) == 1:
                                    base.append(tmp)
                    # without_edge
                    """
                    for p in range(1, my_size-1):
                        for q in range(1, my_size-1):
                            for r in range(1, my_size-1):
                                a = p / (my_size - 1)
                                b = q / (my_size - 1)
                                c = r / (my_size - 1)
                                d = 1 - a - b - c
                                tmp = [a, b, c, d]
                                if d >= 0 and sum(tmp) == 1:
                                    #print(tmp)
                                    base.append(tmp)
                    """
                #print(len(base))

                for j in range(model.families[i].size):

                    if election_model in {'unid', 'stan'}:
                        param_1 = j / (model.families[i].size - 1)
                    elif election_model in {'anid', 'stid', 'anun', 'stun'}:
                        param_1 = (j+1) / (model.families[i].size + 1)
                        #print(param_1)
                    elif election_model in {'crate'}:
                        param_1 = base[j]
                    elif election_model == 'urn' and copy_param_1 == -2.:
                        param_1 = round(j/10000., 2)

                    elections_id = "core_" + str(id_)
                    el.generate_elections(experiment_id, election_model=election_model, election_id=elections_id,
                                          num_voters=model.num_voters, num_candidates=model.num_candidates,
                                          special=param_1)
                    id_ += 1

        else:
            id_ += model.families[i].size


def prepare_elections_extended(experiment_id):

    model = obj.Model(experiment_id)

    id_ = 800
    for i in range(30, model.num_families):
        elections_type = model.families[i].name
        special_1 = model.families[i].special_1
        special_2 = model.families[i].special_2
        num_elections = 1

        # list of IDs larger than 10
        if elections_type == 'dublin':
            folder = 'dublin_s1'
            ids = [1, 3]
        elif elections_type == 'glasgow':
            folder = 'glasgow_s1'
            ids = [2,3,4,5,6,7,8,9,11,13,16,19,21]
        elif elections_type == 'formula':
            elections_type = 'formula'
            folder = 'formula_s1'
            ids = [i for i in range(48)]
        elif elections_type == 'skate':
            folder = 'skate_ic'
            ids = [i for i in range(48)]
        elif elections_type == 'sushi':
            folder = 'sushi_ff'
            ids = [1]

        rand_ids = rand.choices(ids, k=model.families[i].size)
        for ri in rand_ids:
            elections_id = "core_" + str(id_)
            tmp_elections_type = elections_type + '_' + str(ri)
            print(tmp_elections_type)
            el.generate_elections_preflib(experiment_id, tmp_elections_type, elections_id, num_elections,
                                  model.num_voters, model.num_candidates, special_1, folder=folder)
            id_ += 1


def prepare_elections_unid(experiment_id):

    model = obj.Model(experiment_id)

    id_ = 900
    #for i in range(35, model.num_families):
    #id_ = 0
    for i in range(model.num_families):
        elections_type = model.families[i].name
        special_1 = model.families[i].special_1
        special_2 = model.families[i].special_2
        num_elections = 1

        print(model.families[0].size)

        for j in range(model.families[i].size):
            special_1 = j
            elections_id = "core_" + str(id_)
            elections_type = 'unid'
            el.generate_elections(experiment_id, elections_type, elections_id, num_elections,
                                  model.num_voters, model.num_candidates, special_1)
            id_ += 1


def compute_distances_between_elections_by_segments(segment, num_segments, experiment_id,
                                                    metric_type="emd", distance_name="positionwise"):

    num_elections = 1
    special = 0

    file_controllers = open("election/" + experiment_id + "/controllers/basic/map.txt", 'r')
    num_voters = int(file_controllers.readline())
    num_candidates = int(file_controllers.readline())
    num_families = int(file_controllers.readline())
    family_name = [0 for _ in range(num_families)]
    family_special = [0 for _ in range(num_families)]
    family_size = [0 for _ in range(num_families)]

    for i in range(num_families):
        line = file_controllers.readline().replace(" ", "").rstrip("\n").split(',')

        family_name[i] = line[1]
        if family_name[i] in {"didi", "pl"}:
            family_special[i] = str(line[2])
        else:
            family_special[i] = float(line[2])
        family_size[i] = int(line[0])

    file_controllers.close()

    number_of_elections = sum(family_size)


    #2 COMPUTE DISTANCES

    print("START", segment)

    results = []

    total = number_of_elections*(number_of_elections-1)/2

    ctr = -1

    for i in range(number_of_elections):
        #print(i)

        for j in range(i + 1, number_of_elections):
            ctr += 1

            if not (segment * total / float(num_segments) <= ctr < (segment + 1) * total / float(num_segments)):
                continue

            elections_id_a = "core_" + str(i)
            elections_id_b = "core_" + str(j)
            elections_ids = [elections_id_a, elections_id_b]

            result = metr.get_distance(experiment_id, distance_name, elections_ids, metric_type)
            print(i,j,result[0])
            results.append(result[0])

    #print(results)


    """
    results2 = []

    for i in range(number_of_elections):
        print(i)
        for j in range(i + 1, number_of_elections):
            elections_id_a = "core_" + str(i)
            elections_id_b = "core_" + str(j)
            elections_ids = [elections_id_a, elections_id_b]

            distance_name = "matrix_metric"
            distance = metr.get_distance(distance_name, elections_ids)

            results2.append(distance[0])
    """

    #3 SAVE RESULTS TO FILE

    if segment == 0:

        file_name = "election/" + experiment_id + "/results/distances/" + str(experiment_id) + "_info.txt"
        file_ = open(file_name, 'w')
        file_.write(str(number_of_elections) + "\n")
        file_.write(str(num_families) + "\n")
        file_.write(str(total) + "\n")
        file_.close()

    ctr = -1
    real_ctr = 0
    file_name = "election/" + experiment_id + "/results/distances/" + str(experiment_id) + "_" + str(segment) +".txt"
    file_ = open(file_name, 'w')
    file_.write(str(len(results)) + "\n")

    for i in range(number_of_elections):

        for j in range(i + 1, number_of_elections):
            ctr += 1

            if not (segment * total / float(num_segments) <= ctr < (segment + 1) * total / float(num_segments)):
                continue

            file_.write(str(i) + ' ' + str(j) + ' ' + str(results[real_ctr]) + "\n")
            real_ctr += 1

    file_.close()

    #4 ANALYSIS

    """
    print(stats.pearsonr(results, results2))
    plt.scatter(results, results2)
    plt.show()
    """


def compute_lacknerwise_distances_between_elections_by_segments(segment, num_segments, experiment_id):
    compute_distances_between_elections_by_segments(segment, num_segments, experiment_id,
                                                                distance_name="lacknerwise", metric_type="l2")


def compute_lacknerwise_distances(experiment_id):
    compute_distances_between_elections(experiment_id, distance_name="lacknerwise", metric_type="l2")



def compute_distances_between_elections_old(experiment_id, metric_type="emd",
            distance_name="positionwise"):


    num_elections = 1
    special = 0

    file_controllers = open("election/" + experiment_id + "/controllers/basic/map.txt", 'r')
    num_voters = int(file_controllers.readline())
    num_candidates = int(file_controllers.readline())
    num_families = int(file_controllers.readline())
    family_name = [0 for _ in range(num_families)]
    family_special = [0 for _ in range(num_families)]
    family_size = [0 for _ in range(num_families)]

    for i in range(num_families):
        line = file_controllers.readline().replace(" ", "").rstrip("\n").split(',')

        family_name[i] = line[1]
        if family_name[i] in {"didi", "pl"}:
            family_special[i] = str(line[2])
        else:
            family_special[i] = float(line[2])
        family_size[i] = int(line[0])

    file_controllers.close()

    number_of_elections = sum(family_size)

    # 2 COMPUTE DISTANCES

    print("START")

    results = []

    for i in range(0, number_of_elections):
        #print(i)
        for j in range(i + 1, number_of_elections):
            elections_id_a = "core_" + str(i)
            elections_id_b = "core_" + str(j)
            elections_ids = [elections_id_a, elections_id_b]
            result = metr.get_distance(experiment_id, distance_name, elections_ids, metric_type)
            print(i,j, round(result[0],2))
            results.append(result[0])

    """
    results2 = []

    for i in range(number_of_elections):
        print(i)
        for j in range(i + 1, number_of_elections):
            elections_id_a = "core_" + str(i)
            elections_id_b = "core_" + str(j)
            elections_ids = [elections_id_a, elections_id_b]

            distance_name = "matrix_metric"

            result = metr.get_distance(experiment_id, distance_name, elections_ids, metric_type)
            results2.append(result[0])
    """

    # 3 SAVE RESULTS TO FILE

    #"""
    ctr = 0
    file_name = "election/" + experiment_id + "/results/distances/" + str(distance_name) + ".txt"
    file_ = open(file_name, 'w')
    file_.write(str(number_of_elections) + "\n")
    file_.write(str(num_families) + "\n")
    file_.write(str(len(results)) + "\n")
    for i in range(number_of_elections):
        for j in range(i + 1, number_of_elections):
            file_.write(str(i) + ' ' + str(j) + ' ' + str(results[ctr]) + "\n")
            ctr += 1
    file_.close()
    #"""

    """
    ctr = 0
    file_name = "election/" + experiment_id + "/results/distances/" + str(experiment_id) + "2.txt"
    file_ = open(file_name, 'w')
    file_.write(str(number_of_elections) + "\n")
    file_.write(str(num_families) + "\n")
    file_.write(str(len(results)) + "\n")
    for i in range(number_of_elections):
        for j in range(i + 1, number_of_elections):
            file_.write(str(i) + ' ' + str(j) + ' ' + str(results2[ctr]) + "\n")
            ctr += 1
    file_.close()
    """


def compute_distances_between_elections(experiment_id, metric_type='emd', distance_name='positionwise', starting_from=0):

    if starting_from == 0:
        model = obj.Model(experiment_id, metric=distance_name)
    else:
        model = obj.Model_xd(experiment_id, metric=distance_name)

    results = []

    for i in range(0, model.num_elections):
        print(i)
        for j in range(i + 1, model.num_elections):

            if j < starting_from:
                old_result = model.distances[i][j]
                results.append(old_result)
            else:
                elections_id_a = "core_" + str(i)
                elections_id_b = "core_" + str(j)
                elections_ids = [elections_id_a, elections_id_b]
                result = metr.get_distance(experiment_id, elections_ids, distance_name=distance_name, metric_name=metric_type)
                #print(result)
                results.append(result)

    ctr = 0
    path = os.path.join(os.getcwd(), "election", experiment_id, "controllers", "distances", str(distance_name) + ".txt")
    with open(path, 'w') as txtfile:
        txtfile.write(str(model.num_elections) + '\n')
        txtfile.write(str(model.num_families) + '\n')
        txtfile.write(str(len(results)) + '\n')
        for i in range(model.num_elections):
            for j in range(i + 1, model.num_elections):
                txtfile.write(str(i) + ' ' + str(j) + ' ' + str(results[ctr]) + '\n')
                ctr += 1


def generate_votes_from_distances(experiment_id, num_points=800):

    tmp = "positionwise"

    file_name = "election/" + experiment_id + "/controllers/distances/" + str(tmp) + ".txt"
    file_ = open(file_name, 'r')

    real_num_points = int(file_.readline())
    num_families = int(file_.readline())
    num_distances = int(file_.readline())

    votes = [[k for k in range(num_points)] for _ in range(num_points)]
    distances = [[0. for _ in range(num_points)] for _ in range(num_points)]

    for i in range(real_num_points):
        for j in range(i + 1, real_num_points):
            line = file_.readline().split(' ')
            if i < num_points and j < num_points:
                distances[i][j] = float(line[2])
                if distances[i][j] == 0.:
                    distances[i][j] == 0.01
                distances[j][i] = distances[i][j]

    for j in range(num_points):
        votes[j] = [x for _, x in sorted(zip(distances[j], votes[j]))]

    file_name = "election/" + experiment_id + "/elections/votes/" + str(experiment_id) + ".txt"
    file_votes = open(file_name, 'w')

    randomized_order = [x for x in range(num_points)]
    #rand.shuffle(randomized_order)

    for j in range(num_points):
        for k in range(num_points):
            r = randomized_order[j]
            file_votes.write(str(votes[r][k]) + "\n")

    file_votes.close()

    file_name = "election/" + experiment_id + "/elections/info/" + str(experiment_id) + ".txt"
    file_info = open(file_name, 'w')
    file_info.write(str(0) + "\n")
    file_info.write(str(1) + "\n")
    file_info.write(str(num_points) + "\n")
    file_info.write(str(num_points) + "\n")
    file_info.close()


def compute_canonical_winners(experiment_id, method="approx_cc", num_winners=800):

    generate_votes_from_distances(experiment_id)

    rule = {'type': method,
            'name': 0,
            'length': 0,
            'special': 0,
            'pure': False}

    winners = win.generate_winners(experiment_id, num_winners, rule, method, experiment_id)

    return winners


def compute_time(experiment_id):

    rule = {'type': 'borda_owa',
             'name': 0,
             'length': 0,
             'special': 0,
             'pure': False}

    #file_read = open("abbey/hist_data_md/cc.txt", 'r')
    #spam_line_1 = int(file_read.readline())
    #num_winners = int(file_read.readline())

    time_table = []

    #for w in range(num_winners):
        #id = int(file_read.readline())

    method = "hb"
    num_winners = 10

    #for w in {680, 681, 682, 740, 741, 742}:
    for w in range(100):

        elections_id = "core_" + str(w)
        print(elections_id)

        start_time = time.time()

        win.generate_winners(experiment_id, num_winners, rule, method, elections_id)

        elapsed_time = time.time() - start_time

        print(w, elapsed_time)
        time_table.append(elapsed_time)

    file_write = open("election/" + experiment_id + "/controllers/times/" + str(method) + ".txt", 'w')
    file_write.write(str(len(time_table)) + "\n")

    for i in range(len(time_table)):
        file_write.write(str(time_table[i]) + "\n")
    file_write.close()


def save_to_soc(experiment_id, winners):

    for idx, winner in enumerate(winners):

        elections_id = "core_" + str(int(winner))

        elections, params = el.import_elections(experiment_id, elections_id)

        num_elections = 1
        num_candidates = params['candidates']
        num_voters = params['voters']

        file_name = "election/" + experiment_id + "/preflib/soc/" + str(experiment_id) + '_' + str(idx) + ".soc"

        file_ = open(file_name, 'w')

        file_.write(str(num_candidates) + "\n")

        for i in range(num_candidates):
            file_.write(str(i+1) + ', ' + chr(97+i) + "\n")

        c = Counter(map(tuple, elections['votes'][0]))
        counted_votes = [[count, list(row)] for row, count in c.items()]
        counted_votes = sorted(counted_votes, reverse=True)

        file_.write(str(num_voters) + ', ' + str(num_voters) + ', ' + str(len(counted_votes)) + "\n")

        for i in range(len(counted_votes)):

            file_.write(str(counted_votes[i][0]) + ', ')

            for j in range(num_candidates):
                file_.write(str(counted_votes[i][1][j]))
                if j < num_candidates - 1:
                    file_.write(", ")
                else:
                    file_.write("\n")

        file_.close()


def compute_canonical_order(experiment_id, method, num_winners):

    """
    rule = {'type': method,
            'name': 0,
            'length': num_winners,
            'special': 0,
            'pure': False}

    orders = win.generate_winners(experiment_id, num_winners, rule, method, experiment_id)
    win.generate_winners(experiment_id, num_winners, rule, method, elections_id)

    return orders
    """
    return 0


def create_structure(experiment_id):

    os.mkdir("election/"+experiment_id)

    os.mkdir("election/"+experiment_id+"/controllers")
    os.mkdir("election/"+experiment_id+"/controllers/params")
    os.mkdir("election/"+experiment_id+"/controllers/advanced")
    os.mkdir("election/"+experiment_id+"/controllers/basic")

    os.mkdir("election/"+experiment_id+"/elections")
    os.mkdir("election/"+experiment_id+"/elections/soc_positionwise_approx_cc")
    os.mkdir("election/"+experiment_id+"/elections/soc_original")

    os.mkdir("election/"+experiment_id+"/controllers")
    os.mkdir("election/"+experiment_id+"/controllers/distances")
    os.mkdir("election/"+experiment_id+"/controllers/times")
    os.mkdir("election/"+experiment_id+"/controllers/orders")
    os.mkdir("election/"+experiment_id+"/controllers/points")


def get_num_candidates(experiment_id, short_id, folder):

    path = os.path.join(os.getcwd(), 'real_data', folder, short_id + '.txt')
    with open(path, 'r') as txtfile:
        num_voter = int(txtfile.readline().strip())
        num_candidates = int(txtfile.readline().strip())

    return num_candidates


def get_num_voters(experiment_id, short_id, folder):

    path = os.path.join(os.getcwd(), 'real_data', folder, short_id + '.txt')
    with open(path, 'r') as txtfile:
        num_voter = int(txtfile.readline().strip())
        num_candidates = int(txtfile.readline().strip())

    return num_voter


def create_structure_with_controllers(experiment_id, short_id, num_candidates):

    os.mkdir("election/"+experiment_id)

    os.mkdir("election/"+experiment_id+"/controllers")
    os.mkdir("election/"+experiment_id+"/controllers/params")
    #os.mkdir("election/"+experiment_id+"/controllers/advanced")
    os.mkdir("election/"+experiment_id+"/controllers/basic")

    os.mkdir("election/"+experiment_id+"/elections")
    #os.mkdir("election/"+experiment_id+"/elections/soc_positionwise_approx_cc")
    os.mkdir("election/"+experiment_id+"/elections/soc_original")

    os.mkdir("election/"+experiment_id+"/results")
    os.mkdir("election/"+experiment_id+"/results/distances")
    #os.mkdir("election/"+experiment_id+"/results/times")
    #os.mkdir("election/"+experiment_id+"/results/orders")
    #os.mkdir("election/"+experiment_id+"/results/points")

    path = os.path.join(os.getcwd(), 'election', experiment_id, 'controllers', 'basic', 'meta.csv')
    with open(path, 'w', newline='') as csvfile:

        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(['key', 'value'])
        writer.writerow(['num_voters', str(100)])
        writer.writerow(['num_candidates', str(num_candidates)])
        writer.writerow(['num_families', str(1)])
        writer.writerow(['num_elections', str(100)])

    path = os.path.join(os.getcwd(), 'election', experiment_id, 'controllers', 'basic', 'map.csv')
    with open(path, 'w', newline='') as csvfile:

        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(['family_size', 'election_model', 'param_1', 'param_2', 'color', 'alpha', 'nice_name', 'show'])
        writer.writerow(['100', short_id, '0', '0', 'black', '1', 'NoNaMe', 'process_id'])

    return num_candidates


def create_structure_test(experiment_id):

    os.mkdir("election/"+experiment_id)

    os.mkdir("election/"+experiment_id+"/controllers")
    os.mkdir("election/"+experiment_id+"/controllers/params")
    os.mkdir("election/"+experiment_id+"/controllers/basic")

    os.mkdir("election/"+experiment_id+"/elections")
    os.mkdir("election/"+experiment_id+"/elections/soc_original")

    os.mkdir("election/"+experiment_id+"/controllers")
    os.mkdir("election/"+experiment_id+"/controllers/distances")
    os.mkdir("election/"+experiment_id+"/controllers/times")
    os.mkdir("election/"+experiment_id+"/controllers/orders")
    os.mkdir("election/"+experiment_id+"/controllers/points")
    os.mkdir("election/"+experiment_id+"/controllers/scores")

    path = os.path.join(os.getcwd(), 'election', experiment_id, 'controllers', 'basic', 'meta.csv')
    with open(path, 'w', newline='') as csvfile:

        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(['key', 'value'])
        writer.writerow(['num_voters', '100'])
        writer.writerow(['num_candidates', '10'])
        writer.writerow(['num_families', '2'])
        writer.writerow(['num_elections', '30'])

    path = os.path.join(os.getcwd(), 'election', experiment_id, 'controllers', 'basic', 'map.csv')
    with open(path, 'w', newline='') as csvfile:

        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(['family_size', 'election_model', 'param_1', 'param_2', 'color', 'alpha', 'nice_name', 'show'])
        writer.writerow(['15', 'impartial_culture', '0', '0', 'black', '1', 'NoNaMe', 'process_id'])
        writer.writerow(['15', 'urn', '0.2', '0', 'red', '1', 'NoNaMe', 'process_id'])



def rearrange_time_format(experiment_id):

    experiment_id = "final"
    type = "hb"

    num_elections = 860
    time_table = []

    for i in range(num_elections):
        file_name = "election/" + experiment_id + "/controllers/orders" + \
                    "/core_" + str(i) + "_" + str(type) + ".txt"
        file_ = open(file_name, 'r')
        spam_line_1 = int(file_.readline())
        spam_line_2 = int(file_.readline())
        time = float(file_.readline())
        time_table.append(time)
        file_.close()

    file_name = "election/" + experiment_id + "/controllers/times/" + experiment_id + "_" + str(type) + ".txt"
    file_ = open(file_name, 'w')
    file_.write(str(num_elections) + "\n")

    for i in range(num_elections):
        file_.write(str(time_table[i]) + "\n")

    file_.close()


def intro(experiment_id):

    print("intro")


def convert_to_soc(experiment, num_elections=None, name=None):

    for id in range(num_elections):

        elections_id = "core_" + str(id)

        elections, params = el.import_elections(experiment, elections_id)

        #num_elections = 1
        num_candidates = params['candidates']
        num_voters = params['voters']

        file_name = "election/" + experiment + "/elections/soc_original/core_" + str(id) + ".soc"

        file_ = open(file_name, 'w')

        file_.write("# " + name + "\n")
        file_.write(str(num_candidates) + "\n")

        for i in range(num_candidates):
            file_.write(str(i+1) + ', ' + 'c' + str(i+1) + "\n")

        c = Counter(map(tuple, elections['votes'][0]))
        counted_votes = [[count, list(row)] for row, count in c.items()]
        counted_votes = sorted(counted_votes, reverse=True)

        file_.write(str(num_voters) + ', ' + str(num_voters) + ', ' + str(len(counted_votes)) + "\n")

        for i in range(len(counted_votes)):

            file_.write(str(counted_votes[i][0]) + ', ')

            for j in range(num_candidates):
                file_.write(str(counted_votes[i][1][j]))
                if j < num_candidates - 1:
                    file_.write(", ")
                else:
                    file_.write("\n")

        file_.close()


def prepare_approx_cc_order(name, limit=200):

    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "orders", "positionwise_approx_cc.txt")
    file_ = open(file_name, 'r')

    spam_ = int(file_.readline())
    num_elections = int(file_.readline())
    spam_ = str(file_.readline())

    for i in range(limit):

        target = str(file_.readline().replace("\n", ""))

        src = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
        src = os.path.join(src, "election", str(name), "elections", "soc_original", "core_" + str(target) + ".soc")

        dst = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
        dst = os.path.join(dst, "election", str(name), "elections", "soc_positionwise_approx_cc", "core_" + str(i) + ".soc")

        copyfile(src, dst)


def show_new_ilp(name, metric="bordawise"):

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "times", "final_core_hb.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())

    times = [float(file_.readline()) for _ in range(num_elections)]

    target = [i for i in range(0,30)]

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "distances", "bordawise.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())
    file_.readline()
    file_.readline()

    distances = [0. for _ in range(800)]

    for i in range(num_elections):
        for j in range(i+1, num_elections):
            line = file_.readline().replace("\n", "").split(" ")
            #print(i,j, line[2])
            dist = float(line[2])

            if j in target:
                distances[i] += dist

            if i in target:
                distances[j] += dist

    #print(distances)

    print(len(times), len(distances))

    """
    limit = 300
    for i in range(num_elections):
        if times[i] > limit:
            times[i] = limit
    """

    distances = [x/30. for x in distances]

    #times = np.log(times)
    times = np.log(times)
    pear = stats.pearsonr(times, distances)
    pear = round(pear[0],2)
    print(pear)

    exp_name = name
    model = obj.Model_xd(exp_name, metric)

    print(model.families[0].size)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    #plt.axis('off')

    left = 0
    for k in range(model.num_families):
        right = left + model.families[k].size
        ax.scatter(distances[left:right], times[left:right],
                   color=model.families[k].color, label=model.families[k].label,
                   alpha=model.families[k].alpha, s=9)
        left = right

    title_text = str(model.num_voters) + " voters  x  " + str(model.num_candidates) + " candidates"
    pear_text = "PCC = " + str(pear)
    add_text = ax.text(0.7, 0.8, pear_text, transform=ax.transAxes)
    plt.title(title_text)
    plt.xlabel("average distance from IC elections")
    plt.ylabel("log ( time )")
    core = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(core, "images", str(exp_name) + "_map.png")
    lgd = ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.savefig(file_name, bbox_extra_artists=(lgd, add_text), bbox_inches='tight')
    plt.show()


def show_new_zip(name):

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "zip_size.txt")
    file_ = open(file_name, 'r')

    num_elections = 800 #int(file_.readline())

    times = [float(file_.readline()) for _ in range(num_elections)]

    target = [i for i in range(0,30)]

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "distances", "positionwise.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())
    file_.readline()
    file_.readline()

    distances = [0. for _ in range(800)]

    for i in range(num_elections):
        for j in range(i+1, num_elections):
            line = file_.readline().replace("\n", "").split(" ")
            #print(i,j, line[2])
            dist = float(line[2])

            if j in target:
                distances[i] += dist

            if i in target:
                distances[j] += dist

    #print(distances)

    print(len(times), len(distances))

    """
    limit = 300
    for i in range(num_elections):
        if times[i] > limit:
            times[i] = limit
    """

    distances = [x/30. for x in distances]

    pear = stats.pearsonr(times, distances)
    pear = round(pear[0],2)
    print(pear)

    exp_name = name
    model = obj.Model_xd(exp_name)

    print(model.families[0].size)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    #plt.axis('off')

    left = 0
    for k in range(model.num_families):
        right = left + model.families[k].size
        ax.scatter(distances[left:right], times[left:right],
                   color=model.families[k].color, label=model.families[k].label,
                   alpha=model.families[k].alpha, s=9)
        left = right

    title_text = str(model.num_voters) + " voters  x  " + str(model.num_candidates) + " candidates"
    add_text = ax.text(0.7, 0.8, "", transform=ax.transAxes)
    plt.title(title_text)
    plt.xlabel("average distance from IC elections")
    plt.ylabel("normalized zip size")
    core = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(core, "images", str(exp_name) + "_zip.png")
    lgd = ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.savefig(file_name, bbox_extra_artists=(lgd, add_text), bbox_inches='tight')
    plt.show()


def show_new_approx_removal(name):

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "approx", "final_core_hb_removal_dis.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())

    times = [float(file_.readline()) for _ in range(num_elections)]

    target = [i for i in range(0,30)]

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "distances", "positionwise.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())
    file_.readline()
    file_.readline()

    distances = [0. for _ in range(800)]

    for i in range(num_elections):
        for j in range(i+1, num_elections):
            line = file_.readline().replace("\n", "").split(" ")
            #print(i,j, line[2])
            dist = float(line[2])

            if j in target:
                distances[i] += dist

            if i in target:
                distances[j] += dist

    #print(distances)

    print(len(times), len(distances))

    """
    limit = 300
    for i in range(num_elections):
        if times[i] > limit:
            times[i] = limit
    """

    distances = [x/30. for x in distances]

    pear = stats.pearsonr(times, distances)
    pear = round(pear[0],2)
    print(pear)

    exp_name = name
    model = obj.Model_xd(exp_name)

    print(model.families[0].size)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    #plt.axis('off')


    plt.ylim(0.98,1.25)

    left = 0
    for k in range(model.num_families):
        right = left + model.families[k].size
        ax.scatter(distances[left:right], times[left:right],
                   color=model.families[k].color, label=model.families[k].label,
                   alpha=model.families[k].alpha, s=9)
        left = right

    title_text = str(model.num_voters) + " voters  x  " + str(model.num_candidates) + " candidates"
    add_text = ax.text(0.7, 0.8, "", transform=ax.transAxes)
    plt.title(title_text)
    plt.xlabel("average distance from IC elections")
    plt.ylabel("REMOVAL")
    core = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(core, "images", str(exp_name) + "_removal.png")
    lgd = ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.savefig(file_name, bbox_extra_artists=(lgd, add_text), bbox_inches='tight')
    plt.show()


def show_new_approx_greedy(name):

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "approx", "final_core_hb_greedy_dis.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())


    times = [float(file_.readline()) for _ in range(num_elections)]

    target = [i for i in range(0, 30)]

    name = "example_100_100"
    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", str(name), "controllers", "distances", "positionwise.txt")
    file_ = open(file_name, 'r')

    num_elections = int(file_.readline())
    file_.readline()
    file_.readline()

    distances = [0. for _ in range(800)]

    for i in range(num_elections):
        for j in range(i + 1, num_elections):
            line = file_.readline().replace("\n", "").split(" ")
            # print(i,j, line[2])
            dist = float(line[2])

            if j in target:
                distances[i] += dist

            if i in target:
                distances[j] += dist

    # print(distances)

    print(len(times), len(distances))

    """
    limit = 300
    for i in range(num_elections):
        if times[i] > limit:
            times[i] = limit
    """

    distances = [x / 30. for x in distances]

    pear = stats.pearsonr(times, distances)
    pear = round(pear[0], 2)
    print(pear)

    exp_name = name
    model = obj.Model_xd(exp_name)

    print(model.families[0].size)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    # plt.axis('off')

    plt.ylim(0.98,1.25)

    left = 0
    for k in range(model.num_families):
        right = left + model.families[k].size
        ax.scatter(distances[left:right], times[left:right],
                   color=model.families[k].color, label=model.families[k].label,
                   alpha=model.families[k].alpha, s=9)
        left = right

    title_text = str(model.num_voters) + " voters  x  " + str(model.num_candidates) + " candidates"
    add_text = ax.text(0.7, 0.8, "", transform=ax.transAxes)
    plt.title(title_text)
    plt.xlabel("average distance from IC elections")
    plt.ylabel("GREEDY")
    core = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(core, "images", str(exp_name) + "_greedy.png")
    lgd = ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.savefig(file_name, bbox_extra_artists=(lgd, add_text), bbox_inches='tight')
    plt.show()


#### NEW ####

#def compute_cloud_distance(experiment_id, x=-1, num_clouds=100, cloud_size=10,  method="", num_candidates=0):
def compute_cloud_distance(experiment_id, x=-1, num_clouds=100, cloud_size=1, method="", num_candidates=0):

    num_voters = 100
    num_elections = 1
    elections_type = method
    #print(method, x)

    distance_name = "positionwise"
    metric_type = "emd"

    # COMPUTE ALL 'GUESS' ELECTIONS

    for T1 in range(num_clouds * cloud_size):
        elections_id_a = "guess_" + str(T1)
        el.generate_elections(experiment_id, elections_type, elections_id_a, num_elections,
                              num_voters, num_candidates, x)

    # COMPUTE ALL DISTANCES
    distances = np.zeros(num_clouds)
    for c in range(num_clouds):
        #print(c)
        cost_table = np.zeros([cloud_size, cloud_size])
        for T1 in range(cloud_size):
            for T2 in range(cloud_size):
                elections_id_a = "guess_" + str(c*cloud_size + T1)
                elections_id_b = "core_" + str(c*cloud_size + T2)
                elections_ids = [elections_id_a, elections_id_b]
                cost_table[T1][T2] = metr.get_distance(experiment_id, distance_name, elections_ids, metric_type)[0]

        # FIND MINIMAL MATCHING
        measure = metr.get_minimal_matching_cost(cost_table, cloud_size)
        measure /= float(cloud_size)
        #print(measure)
        distances[c] = measure

    for T1 in range(num_clouds * cloud_size):
        file_name = "guess_" + str(T1) + '.soc'
        path = os.path.join(os.getcwd(), 'election', experiment_id, 'elections', 'soc_original', file_name)
        try:
            os.remove(path)
        except:
            print("Cannot remove the file!")

    return np.mean(distances)


def approx_real_data(exp_name, method, num_candidates):

    if method in ["impartial_culture", "identity", "netflix", "sushi", "formula",
                  "meath", "dublin_north",  "dublin_west", "equality",
                  "1d_interval", "2d_square", "single_crossing"]:
        min_value = compute_cloud_distance(exp_name, method=method, num_candidates=num_candidates)

    elif method == "urn" or method == "mallows"\
            or method == "didi" or method == "pl":

        params = import_params(exp_name, method, num_candidates)
        min_value = compute_cloud_distance(exp_name, x=params, method=method, num_candidates=num_candidates)

    #elif method == "mallows05":
    #    min_value = compute_cloud_distance(exp_name, x=[0.5], method=method, num_candidates=num_candidates)


    print(round(min_value,5))

    file_name = os.path.join("election", str(exp_name), "controllers", "distances", method +  ".txt")
    file_ = open(file_name, 'w')
    file_.write(str(min_value) + "\n")
    file_.close()
    #print("DONE")


def import_params(experiment_id, method, num_candidates):

    file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    file_name = os.path.join(file_name, "election", experiment_id, "controllers", "params", method + ".txt")
    file_ = open(file_name, 'r')
    params = []

    if method == "urn" or method == "mallows":
        params = float(file_.readline())

    elif method == "didi" or method == "pl":
        [params.append(float(file_.readline())) for _ in range(num_candidates)]

    file_.close()
    return params

ctr = 0

def approx_training(exp_name, method, target, num_candidates, n_calls=100, num_clouds=5, cloud_size=10):

    def local_optim(x):

        if len(x) == 1:
            x = x[0]

        num_voters = 100
        num_elections = 1
        second_x = -1

        distance_name = "positionwise"
        metric_type = "emd"

        # compute all 'guess' elections
        for T1 in range(num_clouds * cloud_size):
            elections_id_a = "guess_" + str(T1)
            el.generate_elections(exp_name, method, elections_id_a, num_elections,
                                  num_voters, num_candidates, x)
            elections_id_b = "train_" + str(T1)
            el.generate_elections(exp_name, target, elections_id_b, num_elections,
                                  num_voters, num_candidates, second_x)

        #  compute all distances
        distances = np.zeros(num_clouds)
        for c in range(num_clouds):
            cost_table = np.zeros([cloud_size, cloud_size])
            for T1 in range(cloud_size):
                for T2 in range(cloud_size):
                    elections_id_a = "guess_" + str(c * cloud_size + T1)
                    elections_id_b = "train_" + str(c * cloud_size + T2)
                    elections_ids = [elections_id_a, elections_id_b]
                    cost_table[T1][T2] = \
                        metr.get_distance(exp_name, distance_name, elections_ids, metric_type)[0]

            #  find minimal matching
            measure = metr.get_minimal_matching_cost(cost_table, cloud_size)
            measure /= float(cloud_size)
            distances[c] = measure

        global ctr
        ctr += 1
        print(ctr, round(np.mean(distances), 2))
        return np.mean(distances)

    if method in ["urn", "mallows"]:

        space = [(0., 1.) for _ in range(1)]
        res = gp_minimize(local_optim, space, n_calls=n_calls)
        print(res.x)

    elif method in ["didi", "pl"]:

        space = [(0.00001, 1.) for _ in range(num_candidates)]
        res = gp_minimize(local_optim, space, n_calls=n_calls)

    print(res.x)
    print(res.fun)
    file_name = os.path.join("election", str(exp_name), "controllers", "params", method +  ".txt")
    file_ = open(file_name, 'w')
    for value in res.x:
        file_.write(str(value) + "\n")
    file_.close()
    print("DONE")



# NEW 30.04.2020
def pure_distance(experiment_id, num_candidates, target, size=200):

    num_voters = 100
    num_elections = 1
    x = 0.1

    distance_name = "positionwise"
    metric_type = "emd"

    for num_candidates in [5,10,20,50,100]:
        print("----")

        for x in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1., 2., 3., 4., 5.]:
            print(x)

            distances = np.zeros(size)
            for T1 in range(size):
                    elections_id = "core_" + str(T1)
                    distances[T1] = metr.get_pure_distance(experiment_id, elections_id, target)

            output = np.mean(distances) / diagonal_math(num_candidates)
            print(output)


def bordawise_diagonal(experiment_id="workshop"):

    size = 1

    num_voters = 100
    num_elections = 1
    x = -1

    distance_name = "bordawise"
    metric_type = "emd"

    for num_candidates in [3]:

        distances = np.zeros(size)
        for T1 in range(size):
            elections_id_a = "core_a_" + str(T1)
            el.generate_elections(experiment_id, "impartial_culture", elections_id_a, num_elections,
                                  num_voters, num_candidates, x)
            elections_id_b = "core_b_" + str(T1)
            el.generate_elections(experiment_id, "antagonism", elections_id_b, num_elections,
                                  num_voters, num_candidates, x)
            elections_ids = [elections_id_a, elections_id_b]
            distances[T1] = metr.get_distance(experiment_id, distance_name, elections_ids, metric_type)[0]

        output = np.mean(distances) / diagonal_math(num_candidates)
        print(output/num_voters)


def map_compute_IDEQ(experiment_id, metric_type="emd", distance_name="positionwise"):

    num_lines = 800

    # can be transform into helper function
    results_ID = []

    for i in range(num_lines):
        election_id = "core_" + str(i)
        target = "identity"
        distance = metr.get_pure_distance(experiment_id, election_id, target)
        results_ID.append(round(distance, 2))
        print(i, distance)

    file_name = os.path.join(os.getcwd(), "election", experiment_id, "controllers", "distances", "positionwise_ID.csv")
    with open(file_name, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(["id", "distance"])
        [writer.writerow([it, value]) for it, value in enumerate(results_ID)]

    # can be transform into helper function
    results_EQ = []

    for i in range(num_lines):
        election_id = "core_" + str(i)
        target = "equality"
        distance = metr.get_pure_distance(experiment_id, election_id, target)
        results_EQ.append(round(distance, 2))
        print(i, distance)

    file_name = os.path.join(os.getcwd(), "election", experiment_id, "controllers", "distances", "positionwise_EQ.csv")
    with open(file_name, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(["id", "distance"])
        [writer.writerow([it, value]) for it, value in enumerate(results_EQ)]


def map_normalize_IDEQ(experiment_id, metric_type="emd", distance_name="positionwise"):

    num_lines = 800
    num_candidates = 100

    # IMPORT DISTANCES FROM IDENTITY
    results_ID = []
    file_name = os.path.join(os.getcwd(), "election", experiment_id, "controllers", "distances", "positionwise_ID.csv")
    with open(file_name, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile, delimiter=',')
        for row in reader:
            results_ID.append(float(row['distance']))

    # IMPORT DISTANCES FROM EQUALITY
    results_EQ = []
    file_name = os.path.join(os.getcwd(), "election", experiment_id, "controllers", "distances", "positionwise_EQ.csv")
    with open(file_name, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile, delimiter=',')
        for row in reader:
            results_EQ.append(float(row['distance']))

    # SAVE NORMALIZED VALUES
    file_name = os.path.join(os.getcwd(), "election", experiment_id, "controllers", "advanced", "IDEQ.txt")
    file_output = open(file_name, 'w')

    values = []
    for i in range(num_lines):
        value = results_ID[i] + results_EQ[i]
        values.append(value)

    maximum = max(values)
    minimum = (num_candidates*num_candidates - 1) / 3
    print(maximum, minimum)
    print(maximum/minimum)

    for i in range(num_lines):

        values[i] = (values[i] - minimum) / (maximum - minimum)
        file_output.write(str(round(values[i],4))+"\n")

    file_output.close()






