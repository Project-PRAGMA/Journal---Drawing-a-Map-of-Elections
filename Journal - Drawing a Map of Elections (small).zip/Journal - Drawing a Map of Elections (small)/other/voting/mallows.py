import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from random import choices


def nswap(m):
    return int((m*(m-1))/2)

def generateVoteSwapArray(m):
    S = [[0 for x in range(int(m * (m + 1) / 2) + 1)] for x in range(m + 1)]

    for n in range(m + 1):
        for d in range(0, int((n + 1) * n / 2 + 1)):
            if d == 0:
                S[n][d] = 1
            else:
                S[n][d] = S[n][d - 1] + S[n - 1][d] - S[n - 1][d - n]
    return S

def calculateZpoly(m):
    res=[1]
    for i in range(1,m+1):
        mult=[1]*i
        res2 = [0] * (len(res) + len(mult) - 1)
        for o1, i1 in enumerate(res):
            for o2, i2 in enumerate(mult):
                res2[o1 + o2] += i1 * i2
        res=res2
    return res

def evaluatePolynomial(coeff,x):
    res=0
    for i,c in enumerate(coeff):
        res+=pow(x,i)*c
    return res

def calculateZ(m,phi):
    coeff = calculateZpoly(m)
    return evaluatePolynomial(coeff,phi)

def calcPolyExp(swap_array,m):
    coeff = (nswap(m)+1)*[0]
    for i in range(nswap(m) + 1):
        coeff[i] = i * swap_array[i]
    return coeff

def calcExpect(swap_array,phi,m):
    return evaluatePolynomial(calcPolyExp(swap_array,m),phi)

def calculateRelativeExpected(m,phi,S):
    expect=calcExpect(S[m],phi,m)
    Z= calculateZ(m,phi)
    a_res=expect/Z
    r_res=a_res/nswap(m)
    return a_res, r_res

def emd(vector_1, vector_2, num_candidates):
    dirt = 0.
    for i in range(num_candidates-1):
        surplus = vector_1[i] - vector_2[i]
        dirt += abs(surplus)
        vector_1[i+1] += surplus
    return dirt

def emd_matrix(mat1,mat2,num_canidates):
    costs=[]
    for i in range(num_canidates):
        cost=[]
        for j in range(num_canidates):
            cost.append(emd(mat1[i].copy(),mat2[j].copy(),num_canidates))
        costs.append(cost)
    costs= np.array(costs)
    row_ind, col_ind = linear_sum_assignment(costs)
    return costs[row_ind, col_ind].sum()

def computeInsertionProbas(i,phi):
    probas = (i+1)*[0]
    for j in range(i+1):
        probas[j]=pow(phi,(i+1)-(j+1))
    return probas

def mallowsModel(m,phi):
    vote=[0]
    for i in range(1,m):
        population = list(range(i+1))
        we=computeInsertionProbas(i,phi)
        weights=[w/sum(we) for w in we]
        index=choices(population, weights)
        vote.insert(index[0],i)
    return vote

def mallowsElectionMat(n,m,phi):
    ar = [[0 for i in range(m)] for j in range(m)]
    for i in range(n):
        pref = mallowsModel(m,phi)
        for j in range(m):
            ar[pref[j]][j]+=1
    res = [[ar[i][j]/n for i in range(m)] for j in range(m)]
    return res

def averageDistanceID(n,m,phi,sample):
    ID = []
    for i in range(m):
        tmp = [0] * m
        tmp[i] = 1
        ID.append(tmp)
    summ=0
    for i in range(sample):
        mat = mallowsElectionMat(n, m, phi)
        summ+=emd_matrix(ID,mat,m)
    avg_dist= summ/sample
    diameter_room=(1/3)*(m+1)*(m-1)
    return avg_dist/diameter_room

def expDisIDMallow(path):
    # num different m
    k = 5
    # num different phi
    t = 101
    ar = [[0 for i in range(t)] for j in range(k)]
    for i, m in enumerate([5,10,20,50,100]):
        print(m)
        for j, phi in enumerate(np.linspace(0, 1, t)):
            ar[i][j] = averageDistanceID(4000, m, phi, 1)
    for i, m in enumerate([5,10,20,50,100]):
        plt.plot(np.linspace(0, 1, t), ar[i], label="m=" + str(m))
        plt.legend()
    plt.xlabel('phi')
    plt.ylabel('expected relative swaps')
    plt.savefig(path+'exDisID.pdf')
    plt.close()

#Computes a diagram showing the realtion between phi and expected relative number of swaps in a vote drawn from Mallows model
def expExpSwaps(path):
    S=generateVoteSwapArray(100)
    # num different m
    k = 5
    # num different phi
    t = 101
    ar = [[0 for i in range(t)] for j in range(k)]
    for i, m in enumerate([5,10,20,50,100]):
        print(m)
        for j, phi in enumerate(np.linspace(0, 1, t)):
            ar[i][j] = calculateRelativeExpected(m, phi,S)[1]
    for i, m in enumerate([5,10,20,50,100]):
        plt.plot(np.linspace(0, 1, t), ar[i], label="m=" +str(m))
        plt.legend()
    plt.xlabel('phi')
    plt.ylabel('expected relative swaps')
    plt.savefig(path+'RelativeExpectedSwaps.pdf')
    plt.close()
