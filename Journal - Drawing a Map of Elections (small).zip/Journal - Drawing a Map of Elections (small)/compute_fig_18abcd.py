#!/usr/bin/env python
# This plot was generated using a previous version of mapel library.

from other.voting import advanced as adv

if __name__ == "__main__":

    experiment_id = "preflib_plus"

    adv.compute_highest_plurality_map(experiment_id)
    adv.compute_highest_borda_map(experiment_id)
    adv.compute_highest_copeland_map(experiment_id)
    adv.compute_lowest_dodgson_map(experiment_id)