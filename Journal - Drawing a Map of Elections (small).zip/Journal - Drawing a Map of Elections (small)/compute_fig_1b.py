#!/usr/bin/env python
# This plot was generated using a previous version of mapel library.

from other.voting import canonical as can
from other.voting import modern as mo

if __name__ == "__main__":

    experiment_id = "preflib_plus"
    can.prepare_elections(experiment_id=experiment_id)
    can.compute_distances_between_elections(experiment_id=experiment_id)
    mo.convert_xd_to_2d(experiment_id, num_iterations=10000, random=True, magic=2)