import mapel.elections as mapel


def print_matrix(experiment):
    omit = [
        '5D Uniform',
        '10D Uniform',
        '20D Uniform',
        '3D Sphere',
        '5D Sphere',
        'Urn',
        'Norm-Mallows',
        'ANID',
        'STID',
        'ANUN',
        'STUN',
    ]

    max_dist = {
        'emd-positionwise': 3333,
    }

    saveas = f'matrix_{distance_id}'
    experiment.print_matrix(scale=1 / max_dist[distance_id],
                            rounding=2,
                            ms=9,
                            omit=omit,
                            saveas=saveas,
                            vmin=0, vmax=1)


if __name__ == "__main__":
    experiment_id = 'main_100x100'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(
        experiment_id=f'{experiment_id}',
        distance_id=distance_id,
        embedding_id=embedding_id,
        fast_import=True
    )

    print_matrix(experiment)
