import mapel.elections as mapel

from utils_print import print_features

if __name__ == "__main__":
    experiment_id = 'main_100x100'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'
    embedding_id = 'kk'

    experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                          distance_id=distance_id,
                                                          embedding_id=embedding_id,
                                                          fast_import=True
                                                          )

    feature_ids = {
        'highest_plurality_score': {'value'},
        'highest_borda_score': {'value'},
        'highest_copeland_score': {'value'},
        'lowest_dodgson_score': {'value'},
    }

    print_features(experiment, feature_ids)
