from datetime import time

from matplotlib.transforms import Bbox

import mapel.elections as mapel
import itertools
from scipy.stats import stats
import matplotlib.pyplot as plt
import numpy as np
import math



def print_features(experiment, feature_ids):
    # feature_ids = {


    # 'highest_cc_score': {'dissat'},
    # 'highest_hb_score': {'dissat'},

    # 'lowest_dodgson_score': {'time'},
    # 'highest_hb_score': {'time'},
    # 'highest_cc_score': {'time'},

    # 'greedy_approx_cc_score_normalized': {'value'},
    # 'removal_approx_cc_score_normalized': {'value'},
    # 'banzhaf_cc_score_normalized': {'value'},
    # 'ranging_cc_score_normalized': {'value'},

    # 'greedy_approx_hb_score_normalized': {'value'},
    # 'removal_approx_hb_score_normalized': {'value'},

    # 'highest_pav_score': {'value'},
    # 'clustering': {'value'}
    # 'greedy_approx_hb_score': {'value'},
    # 'removal_approx_hb_score': {'value'},
    # 'highest_hb_score': {'value'},

    # 'num_of_diff_votes': {'value'},
    # 'voterlikeness_sqrt': {'value'},
    # 'voterlikeness_harmonic': {'value'},
    # 'borda_diversity': {'value'}

    # 'greedy_approx_cc_score': {'value'},

    # 'greedy_approx_cc_score_normalized_dissat': {'value'},
    # 'removal_approx_cc_score_normalized_dissat': {'value'},
    # 'banzhaf_cc_score_normalized_dissat': {'value'},
    # 'ranging_cc_score_normalized_dissat': {'value'},

    # 'greedy_approx_hb_score_normalized_dissat': {'value'},
    # 'removal_approx_hb_score_normalized_dissat': {'value'},

    # }

    def copeland_marker_func(x):
        if x == 1.:
            return 'x'
        return 'o'

    def dodgson_marker_func(x):
        # print(x)
        if x == 0:
            return 'x'
        return 'o'

    def dissat_marker_func(x):
        # print(x)
        if x == 0:
            return 'x'
        return 'o'

    marker_func = {
        'highest_copeland_score': copeland_marker_func,
        'lowest_dodgson_score': dodgson_marker_func,
    }

    upper_limit = {
        'lowest_dodgson_score': 600,
        'highest_hb_score': 600,
        'highest_cc_score': 60,
        # 'lowest_dodgson_score': 0.37,
    }

    lower_limit = {
        'greedy_approx_cc_score_normalized': 0.5,
        # 'removal_approx_cc_score_normalized': 3,
        # 'banzhaf_cc_score_normalized': 3,
        # 'ranging_cc_score_normalized': 3,
    }

    rounding = {
        'lowest_dodgson_score': 1,
        'highest_hb_score': 0,
        'greedy_approx_cc_score_normalized': 3,
        'removal_approx_cc_score_normalized': 3,
        'banzhaf_cc_score_normalized': 3,
        'ranging_cc_score_normalized': 3,
    }

    scale = {
        'lowest_dodgson_score_value': 'sqrt',
        'highest_hb_score_time': 'sqrt',
        'highest_cc_score_time': 'sqrt',
    }

    xtickslabels = {
        # 'lowest_dodgson_score': ['0', '155', '311', '466', '622', '777s+'],
        # 'highest_hb_score': ['<.98', '.984', '.988', '.992', '.996', '1'],
    }

    cmaps = {
        'greedy_approx_cc_score_normalized': 'Blues',
        'greedy_approx_cc_score_normalized_dissat': 'Purples_r',
        'removal_approx_cc_score_normalized': 'Reds',
        'removal_approx_cc_score_normalized_dissat': 'Purples_r',
        'banzhaf_cc_score_normalized': 'Greens',
        'banzhaf_cc_score_normalized_dissat': 'Oranges_r',
        'ranging_cc_score_normalized': 'Oranges',
        'ranging_cc_score_normalized_dissat': 'Oranges_r',

        'greedy_approx_hb_score_normalized': 'Blues',
        'greedy_approx_hb_score_normalized_dissat': 'Purples_r',
        'removal_approx_hb_score_normalized': 'Reds',
        'removal_approx_hb_score_normalized_dissat': 'Purples_r',
    }

    streches = {
        'greedy_approx_cc_score_normalized': [0.98, 1],
        'removal_approx_cc_score_normalized': [0.98, 1],
        'banzhaf_cc_score_normalized': [0.98, 1],
        'ranging_cc_score_normalized': [0.98, 1],
        'greedy_approx_hb_score_normalized': [0.995, 1],
        'removal_approx_hb_score_normalized': [0.995, 1],

        'greedy_approx_cc_score_normalized_dissat': [1, 2],
        'removal_approx_cc_score_normalized_dissat': [1, 2],
        'banzhaf_cc_score_normalized_dissat': [1, 20],
        'ranging_cc_score_normalized_dissat': [1, 20],
        'greedy_approx_hb_score_normalized_dissat': [1, 1.01],
        'removal_approx_hb_score_normalized_dissat': [1, 1.01],
    }

    xticks = {
        'greedy_approx_cc_score_normalized_dissat': ['1', '1.2', '1.4', '1.6', '1.8', '2+'],
        'removal_approx_cc_score_normalized_dissat': ['1', '1.2', '1.4', '1.6', '1.8', '2+'],
        'banzhaf_cc_score_normalized_dissat': ['1', '4.8', '8.6', '12.4', '16.2', '20+'],
        'ranging_cc_score_normalized_dissat': ['1', '4.8', '8.6', '12.4', '16.2', '20+'],
        'greedy_approx_hb_score_normalized_dissat': ['1', '1.002', '1.004', '1.006', '1.008',
                                                     '1.01'],
        'removal_approx_hb_score_normalized_dissat': ['1', '1.002', '1.004', '1.006', '1.008',
                                                      '1.01'],

    }

    for feature_id in feature_ids:
        for column_id in feature_ids[feature_id]:
            if '_normalized_dissat' in feature_id:
                experiment.print_map_2d_colored_by_feature(
                    # title=f'{feature_id} ({column_id})',
                    saveas=f'{feature_id}_{column_id}',
                    column_id=column_id,
                    feature_id=feature_id,
                    marker_func=dissat_marker_func,
                    rounding=3,
                    strech=streches.get(feature_id, None),
                    # figsize=(7.50, 7.50)  # for spring
                    figsize=(6.95, 6.95),  # for kamada
                    # feature_labelsize=16,
                    feature_labelsize=12,
                    cmap=cmaps.get(feature_id, mapel.custom_div_cmap(
                        colors=["red", "orange", "yellow", "green", "cyan", "blue", "black"])),

                    xticklabels=xticks.get(feature_id, None),
                    # cmap=mapel.custom_div_cmap(colors=["navy", "purple", "lavenderblush"]),
                    # cmap=mapel.custom_div_cmap(colors=["black", "blue", "cyan", "green", "yellow", "orange", "red"])
                    # cmap=mapel.custom_div_cmap(colors=["red", "orange", "yellow", "green", "cyan", "blue", "black"])
                    # cmap=mapel.custom_div_cmap(colors=["black", "blue", "purple", "red",
                    #                                    "orange", "yellowgreen", "green"]),
                    # cmap=mapel.custom_div_cmap(colors=["lavender", "indigo"]),
                    # xticklabels=['<.98', '.984', '.988', '.992', '.996', '1']
                )
            elif '_normalized' in feature_id:
                experiment.print_map_2d_colored_by_feature(
                    # title=f'{feature_id} ({column_id})',
                    saveas=f'approx_{feature_id}_{column_id}',
                    column_id=column_id,
                    feature_id=feature_id,
                    marker_func=copeland_marker_func,
                    rounding=3,
                    strech=streches.get(feature_id, None),
                    # figsize=(7.50, 7.50)  # for spring
                    figsize=(6.95, 6.95),  # for kamada
                    feature_labelsize=12,
                    cmap=cmaps.get(feature_id, mapel.custom_div_cmap(
                        colors=["red", "orange", "yellow", "green", "cyan", "blue", "black"])),

                    # cmap=mapel.custom_div_cmap(colors=["navy", "purple", "lavenderblush"]),
                    # cmap=mapel.custom_div_cmap(colors=["black", "blue", "cyan", "green", "yellow", "orange", "red"])
                    # cmap=mapel.custom_div_cmap(colors=["red", "orange", "yellow", "green", "cyan", "blue", "black"])
                    # cmap=mapel.custom_div_cmap(colors=["black", "blue", "purple", "red",
                    #                                    "orange", "yellowgreen", "green"]),
                    # cmap=mapel.custom_div_cmap(colors=["lavender", "indigo"]),
                )

            elif column_id in {'value'}:
                experiment.print_map_2d_colored_by_feature(
                    # title=f'{feature_id} ({column_id})',
                    saveas=f'{feature_id}_{column_id}',
                    column_id=column_id,
                    feature_id=feature_id,
                    marker_func=marker_func.get(feature_id, None),
                    rounding=rounding.get(feature_id, 0),
                    # textual=['ID', 'UN', 'AN', 'ST'],
                    scale=scale.get(f'{feature_id}_{column_id}', 'default'),
                    # figsize=(7.50, 7.50)  # for spring
                    figsize=(6.95, 6.95),  # for kamada
                    # figsize=(6, 6),
                    feature_labelsize=12,
                    # bbox_inches=Bbox([[0, 0], [6.4, 6.4]]),

                    # cmap=mapel.custom_div_cmap(colors=["navy", "purple", "lavenderblush"]),
                    # cmap=mapel.custom_div_cmap(colors=["black", "blue", "cyan", "green", "yellow", "orange", "red"]),
                    # cmap='viridis',
                    cmap=mapel.custom_div_cmap(
                        colors=["black", "blue", "purple", "red", "orange", "yellowgreen",
                                "green"]),
                    dpi=300,
                )
            elif column_id in {'dissat'}:
                experiment.print_map_2d_colored_by_feature(
                    # title=f'{feature_id} ({column_id})',
                    saveas=f'{feature_id}_{column_id}',
                    column_id=column_id,
                    feature_id=feature_id,
                    marker_func=marker_func.get(feature_id, None),
                    rounding=rounding.get(feature_id, 0),
                    # textual=['ID', 'UN', 'AN', 'ST'],
                    scale=scale.get(f'{feature_id}_{column_id}', 'default'),
                    # figsize=(7.50, 7.50)  # for spring
                    figsize=(6.95, 6.95),  # for kamada
                    # figsize=(6, 6),
                    feature_labelsize=12,
                    # bbox_inches=Bbox([[0, 0], [6.4, 6.4]]),

                    # cmap=mapel.custom_div_cmap(colors=["navy", "purple", "lavenderblush"]),
                    # cmap=mapel.custom_div_cmap(colors=["black", "blue", "cyan", "green", "yellow", "orange", "red"]),
                    # cmap='viridis',
                    cmap=mapel.custom_div_cmap(
                        colors=["green", "yellowgreen", "orange", "red", "purple", "blue",
                                "black"]),
                    dpi=300,
                )
            elif column_id == 'time':
                experiment.print_map_2d_colored_by_feature(
                    # title=f'{feature_id} ({column_id})',
                    saveas=f'{feature_id}_{column_id}',
                    column_id=column_id,
                    feature_id=feature_id,
                    marker_func=marker_func.get(feature_id, None),
                    rounding=0,
                    # textual=['ID', 'UN', 'AN', 'ST'],
                    scale=scale.get(f'{feature_id}_{column_id}', 'default'),
                    # scale='log',
                    upper_limit=upper_limit.get(feature_id, np.infty),
                    # figsize=(7.50, 7.50)  # for spring
                    figsize=(6.95, 6.95),  # for kamada
                    feature_labelsize=12,
                    # bbox_inches=([[0, 0], [6.4, 6.4]]),
                    xticklabels=xtickslabels.get(feature_id, None),
                    # cmap='Purples',
                    cmap=mapel.custom_div_cmap(colors=["lavenderblush", "purple", "navy"]),
                    # cmap=mapel.custom_div_cmap(colors=["lavender", "indigo"]),
                    # , "orange", "red", "purple", "black"])

                    # rounding=2,
                    # reverse=True,
                    # angle=1.12*math.pi
                )


def print_double_features(experiment, pairs):
    # pairs = [
    #     # ['greedy_approx_cc_score_normalized', 'removal_approx_cc_score_normalized'],
    #     ['greedy_approx_cc_score_normalized_dissat', 'removal_approx_cc_score_normalized_dissat'],
    #
    #     # ['greedy_approx_hb_score_normalized', 'removal_approx_hb_score_normalized'],
    #
    #     # ['greedy_approx_hb_score_normalized_dissat', 'removal_approx_hb_score_normalized_dissat'],
    #     # ['greedy_approx_pav_score_normalized_dissat', 'removal_approx_pav_score_normalized_dissat']
    # ]

    def marker_func(x):
        if x == 0.:
            return 'x'
        return 'o'

    column_id = 'value'

    for feature_id_1, feature_id_2 in pairs:
        # if feature_id_1 == 'greedy_approx_cc_score_normalized':
        #     election.print_map(
        #                             # title=f'{feature_id_1} vs {feature_id_2} ({column_id})',
        #                          saveas=f'thesis/{feature_id_1}_vs_{feature_id_2}',
        #                          column_id=column_id,
        #                          marker_func=marker_func,
        #                          # xticklabels=xticklabels[feature_id],
        #                          # ticks=ticks[feature_id],
        #                          xticklabels=['0.98', '0.984', '0.988', '0.992', '0.996', '1'],
        #                          # rounding=3,
        #                          feature_ids=[feature_id_1, feature_id_2],
        #         # textual=['ID', 'UN', 'AN', 'ST'],
        #         # scale=scale.get(feature_id, 'default'),
        #         # scale='log',
        #         # upper_limit=upper_limit.get(feature_id, np.infty),
        #         figsize=(8.3, 8.3),
        #     )
        # elif feature_id_1 == 'greedy_approx_hb_score_normalized':
        #     election.print_map(
        #                             # title=f'{feature_id_1} vs {feature_id_2} ({column_id})',
        #                          saveas=f'thesis/{feature_id_1}_vs_{feature_id_2}',
        #                          column_id=column_id,
        #                          marker_func=marker_func,
        #                          # xticklabels=xticklabels[feature_id],
        #                          # ticks=ticks[feature_id],
        #                          xticklabels=['0.995', '0.996', '0.997', '0.998', '0.999', '1'],
        #                          # rounding=3,
        #                          feature_ids=[feature_id_1, feature_id_2],
        #         # textual=['ID', 'UN', 'AN', 'ST'],
        #         # scale=scale.get(feature_id, 'default'),
        #         # scale='log',
        #         # upper_limit=upper_limit.get(feature_id, np.infty),
        #         figsize=(8.3, 8.3),
        #     )
        if feature_id_1 == 'greedy_approx_cc_score_normalized_dissat':
            experiment.print_map_2d_colored_by_features(
                # title=f'{feature_id_1} vs {feature_id_2} ({column_id})',
                saveas=f'{feature_id_1}_vs_{feature_id_2}',
                column_id=column_id,
                # marker_func=marker_func,
                # xticklabels=xticklabels[feature_id],
                # ticks=ticks[feature_id],

                xticklabels=['1', '1.1', '1.2', '1.3', '1.4', '1.5+'],
                # rounding=3,
                # strech=[1,1.05],
                feature_ids=[feature_id_1, feature_id_2],
                # textual=['ID', 'UN', 'AN', 'ST'],
                # scale=scale.get(feature_id, 'default'),
                # scale='log',
                # upper_limit=upper_limit.get(feature_id, np.infty),
                upper_limit=1.5,
                # limit=1.5,
                figsize=(8.3, 8.3),
            )
        elif feature_id_1 == 'greedy_approx_hb_score_normalized_dissat':
            experiment.print_map_2d_colored_by_features(
                # title=f'{feature_id_1} vs {feature_id_2} ({column_id})',
                saveas=f'{feature_id_1}_vs_{feature_id_2}',
                column_id=column_id,
                marker_func=marker_func,
                # xticklabels=xticklabels[feature_id],
                # ticks=ticks[feature_id],
                xticklabels=['1', '1.001', '1.002', '1.003', '1.004', '1.005+'],
                # rounding=3,
                feature_ids=[feature_id_1, feature_id_2],
                # textual=['ID', 'UN', 'AN', 'ST'],
                # scale=scale.get(feature_id, 'default'),
                # scale='log',
                upper_limit=1.005,
                figsize=(8.3, 8.3),
            )



