import mapel.elections as mapel

cmap = mapel.custom_div_cmap(colors=["black",
                                     "blue",
                                     "purple",
                                     "red",
                                     "orange",
                                     "yellowgreen",
                                     "green"])


def print_monotonicity(experiment, feature_id):
    experiment.print_map_2d_colored_by_feature(feature_id=feature_id,
                                               strech=[0.45, 1.0],
                                               rounding=2,
                                               saveas=feature_id,
                                               cmap=cmap
                                               )


if __name__ == "__main__":

    embbeding_ids = ['fr', 'kk', 'mds']

    experiment_id = 'main_100x100'
    distance_id = 'emd-positionwise'

    for embedding_id in embbeding_ids:

        experiment = mapel.prepare_offline_ordinal_experiment(
                                              experiment_id=f'{experiment_id}',
                                              distance_id=distance_id,
                                              embedding_id=embedding_id,
                                              fast_import=True
        )

        print_monotonicity(experiment, feature_id=f'monotonicity_{embedding_id}_00')
