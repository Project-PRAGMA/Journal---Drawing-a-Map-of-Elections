
import mapel.elections as mapel


def print_main_map(experiment):
    experiment.print_map_2d(
        legend=False,
        shading=True,
        saveas=f'{embedding_id}_{distance_id}',
        textual_size=16,
    )


if __name__ == "__main__":

    experiment_id = 'main_100x100'
    distance_id = 'emd-positionwise'
    embedding_id = 'fr'

    experiment = mapel.prepare_offline_ordinal_experiment(
                                          experiment_id=experiment_id,
                                          distance_id=distance_id,
                                          embedding_id=embedding_id,
                                          fast_import=True
                                          )

    print_main_map(experiment)
