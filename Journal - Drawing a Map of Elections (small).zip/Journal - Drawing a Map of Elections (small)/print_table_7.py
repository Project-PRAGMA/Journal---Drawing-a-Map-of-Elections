import numpy as np

import mapel.elections as mapel


def compute_special_approx(experiment):
    rounding = {
        'greedy_approx_cc_score_normalized_dissat': 3,
        'removal_approx_cc_score_normalized_dissat': 3,
        'banzhaf_cc_score_normalized_dissat': 2,
        'ranging_cc_score_normalized_dissat': 2,

        'greedy_approx_hb_score_normalized_dissat': 4,
        'removal_approx_hb_score_normalized_dissat': 4,
    }

    feature_ids = [
        'greedy_approx_cc_score_normalized_dissat',
        'removal_approx_cc_score_normalized_dissat',
        'banzhaf_cc_score_normalized_dissat',
        'ranging_cc_score_normalized_dissat',

        'greedy_approx_hb_score_normalized_dissat',
        'removal_approx_hb_score_normalized_dissat',
    ]

    results = {family_id: '' for family_id in experiment.families}

    for feature_id in feature_ids:
        feature = experiment.import_feature(feature_id)
        for family in experiment.families.values():
            if family.family_id in ['ID', 'UN', 'ST', 'AN',
                                    'ANID', 'STID', 'ANUN', 'STUN',
                                    ]:
                continue
            values = []
            for election_id in family.instance_ids:
                value = feature[election_id]

                if value is not None:
                    values.append(value)

            values = np.array(values)
            results[family.family_id] += \
                f'{str(round(np.mean(values), rounding[feature_id]))} & '

    for result in results.values():
        print(result)


if __name__ == "__main__":
    experiment_id = 'main_100x100'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_offline_ordinal_experiment(
        experiment_id=experiment_id,
        distance_id=distance_id,
    )

    compute_special_approx(experiment)
