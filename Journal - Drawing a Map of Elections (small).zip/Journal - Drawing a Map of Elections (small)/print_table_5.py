import numpy as np

import mapel.elections as mapel


def print_special_distortion(experiment):

    for family_id in experiment.families:
        distortions = []
        for election_id_1 in experiment.families[family_id].instance_ids:
            values = []
            for election_id_2 in experiment.instances:
                if election_id_1 == election_id_2:
                    continue

                a = experiment.distances[election_id_1][election_id_2]
                a /= experiment.distances['ID']['UN']
                b = np.linalg.norm(np.array(experiment.coordinates[election_id_1])
                                   - np.array(experiment.coordinates[election_id_2]), ord=2)
                b /= np.linalg.norm(np.array(experiment.coordinates['ID'])
                                   - np.array(experiment.coordinates['UN']), ord=2)
                value = max(a, b) / min(a, b)
                if min(a,b) == 0:
                    continue

                if a > 0.1:
                    values.append(value)

            values = np.array(values)

            distortion = np.mean(values)
            distortions.append(distortion)

        distortions = np.array(distortions)

        if family_id not in ['UN', 'ID', 'ST', 'AN', 'ANID', 'STID', 'ANUN', 'STUN']:
            print(family_id, round(np.mean(distortions), 3))




if __name__ == "__main__":
    embedding_ids = ['fr', 'kk', 'mds']

    experiment_id = 'main_100x100'
    distance_id = 'emd-positionwise'

    for embedding_id in embedding_ids:
        experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                          distance_id=distance_id,
                                          embedding_id=embedding_id,
                                          fast_import=True
                                          )

        print_special_distortion(experiment)
